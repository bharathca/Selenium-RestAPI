package week3.day2;

public interface RBI {
	
	public static final double repoRate = 7.5;

	public abstract void minimumBalance();
	
	void maxLoanAmount();
}
