package week3.day2;

public class ICICI implements Cibil{

	public static void main(String[] args) {
		ICICI bank = new ICICI();
		bank.maxLoanAmount();
		bank.minimumBalance();
		bank.ITLoan();
		bank.creditScore();
	}

	public void minimumBalance() {
		System.out.println(2000);
		
	}

	public void maxLoanAmount() {
		System.out.println(1000000);
	}
	
	public void ITLoan() {
		
	}

	public void creditScore() {
		
	}

}
