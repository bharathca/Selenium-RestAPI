package week3.day1;

public class Vehicle {

	public void applyBrake() {
		System.out.println("Apply brake from Vehicle class");
	}
	
	protected void soundHorn() {
		System.out.println("Sound Horn");
	}
}
