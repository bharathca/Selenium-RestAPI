package week3.day1;

public class Bike extends Vehicle{

	public void rideBike() {
		
	}
	
}
