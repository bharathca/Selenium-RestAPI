package week3.day1;

public class Car extends Vehicle {

	public void driveCar() {
		System.out.println("Drive Car");
	}
	
	public void applyBrake() {
		System.out.println("Apply brake from Car class");
	}
	
}
