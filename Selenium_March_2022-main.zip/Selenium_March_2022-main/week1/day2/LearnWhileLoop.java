package week1.day2;

public class LearnWhileLoop {

	public static void main(String[] args) {
		// Print numbers from 1 to 10
		
		int i = 1;
//		while(i<=10) {
//			System.out.println(i);
//			i++;
//		}
		
		// do while
		do {
			System.out.println(i);
			i++;
		} while(i<=10);
		
	}

}
