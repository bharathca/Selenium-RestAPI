package week1.day1;

public class LearnOperators {

	public static void main(String[] args) {
		System.out.println(2 + 3);
		System.out.println(5 - 10);
		System.out.println(5 * 5);
		System.out.println(10 / 2);
		System.out.println(10 % 4);
		
		System.out.println(2!=3 && 4<5 && 5==6);
		System.out.println(2!=3 || 4<5 || 5==6);
		System.out.println((2!=3 && 4<5) || 5==6);
	}
}
