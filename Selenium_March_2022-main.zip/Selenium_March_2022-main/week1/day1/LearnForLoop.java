package week1.day1;

public class LearnForLoop {

	public static void main(String[] args) {
		// Print numbers from 1 to 10
		// initialize value; condition; increment/ decrement
		for(int i=1; i<=10; i++) {
			if (i%2!=0) {
				System.out.println(i);
			}
		}
	}
}
