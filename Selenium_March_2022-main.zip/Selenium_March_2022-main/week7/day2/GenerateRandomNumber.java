package week7.day2;

public class GenerateRandomNumber {

	public static void main(String[] args) {
		System.out.println(Math.random()*1000);

	}

}
