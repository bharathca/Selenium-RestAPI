package testSteps;

import org.openqa.selenium.By;

import cucumber.api.java.en.*;

public class CreateLeadSteps {

	/*@Given("Click on Leads link")
	public void clickLead()
	{
		driver.findElement(By.linkText("Leads")).click();
	}
	
	@And ("Click on Create Lead link")
	public void clickCreateLead()
	{
		driver.findElement(By.linkText("Create Lead")).click();
	}
	
	@And ("Enter company name as (.*)")
	public void setCmpyName(String cmpyName)
	{
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cmpyName);
	}
	
	@And ("Enter first name as (.*)")
	public void setFirstName(String firstName)
	{
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(firstName);
	}
	
	@And ("Enter Last name as (.*)")
	public void setLastName(String lastName)
	{
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lastName);
	}
	
	@When ("Click on Create Lead button")
	public void clickCreate()
	{
		driver.findElement(By.className("smallSubmit")).click();
	}
	
	@Then ("New Lead should be created")
	public void verifyLead()
	{
		System.out.println(driver.findElement(By.id("viewLead_firstName_sp")).getText());
	}*/
}
