package stepsImpl;

import java.io.File;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class IncidentManagmentSteps {
	
	RequestSpecification inputRequest = null;
	Response response = null;
	
	@Given("user sets the endpoint for the service now Incident Management")
	public void setEndpoint() {
		RestAssured.baseURI = "https://dev92404.service-now.com/api/now/table/incident";
	}
	
	@Given("user sets the authentication for service now application")
	public void setAuthentication() {
		RestAssured.authentication = RestAssured.basic("admin", "$QdCj4vK3C@h");
	}
	
	@Given("user set the queryparams in the request")
	public void setQueryParams(DataTable dt) {
		Map<String, String> queryParams = dt.asMap();
		inputRequest.queryParams(queryParams);
	}
	
	@Given("user sets the request header accepts with Json format")
	public void setAcceptHeader() {
		inputRequest = RestAssured.given().accept(ContentType.JSON);
	}
	
	@Given("user sets the request header content-type with Json format")
	public void setcontentTypeHeader() {
		inputRequest.contentType(ContentType.JSON);
	}
	
	@Given("user add the json file in the request body as {string}")
	public void setFileInRequestBody(String fileName) {
		File inputFile= new File("./src/test/resources/"+fileName+".json");
		inputRequest.body(inputFile);
	}
	
	@When("user sends the POST request for Incident Management")
	public void sendPostRequest() {
		inputRequest.log().all();
		response = inputRequest.post();
		response.then().log().all();
	}
	
	@When("user sends the GET request for Incident Management")
	public void sendGetRequest() {
		inputRequest.log().all();
		response = inputRequest.get();
		response.then().log().all();
	}
	
	@Then("user should get status code {int}")
	public void validateStatusCode(int statusCode) {
		response.then().assertThat().statusCode(statusCode);
	}

}
