package week3.day1;

public class StudentInfo {
	
	public void getStudentDetails(int studentId) {
		
	}
	
	public void getStudentDetails(String studentName) {
		
	}
	
	public void getStudentDetails(int studentId, String studentName) {
		
	}
	
	public void getStudentDetails(String studentName, int studentId) {
		
	}
	
	public void getStudentDetails(String studentId, String studentName) {
		
	}
	
	public static void main(String[] args) {
		StudentInfo si = new StudentInfo();
	}
	

}
