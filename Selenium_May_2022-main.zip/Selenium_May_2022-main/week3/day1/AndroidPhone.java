package week3.day1;

public class AndroidPhone extends Mobile{

	public void takeVideo() {
		System.out.println("Take Video");
	}
}
