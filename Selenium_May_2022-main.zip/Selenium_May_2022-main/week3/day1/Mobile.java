package week3.day1;

public class Mobile {

	public void sendMsg() {
		System.out.println("Send Message");
	}
	
	public void makeCall() {
		System.out.println("Make Call");
	}
	
	public void saveContact() {
		System.out.println("Save Contact");
	}
}
