package week3.day2;

public class OnePlusNewWatch extends OnePlusWatch{

	public void dialCall() {
		// TODO Auto-generated method stub
		
	}

	public void connectToWireless() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getBPM() {
		// TODO Auto-generated method stub
		return 0;
	}

}
