package week3.day2;

import java.util.AbstractList;

public class BuyOnePlusWatch {
	
	public static void main(String[] args) {
			OnePlusNewWatch one = new OnePlusNewWatch();
			one.getBatteryPercentage();
			
	}

}
