package week3.day2;

public interface Phone {
	
	public void sendSMS();
	
	public void dialCall();
	
	public void connectToWireless();


}
