package week3.day2;

public abstract class OnePlusWatch implements SmartWatch, Phone{

	public String getDateTime() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setDateTime(String newDate) {
		// TODO Auto-generated method stub
		
	}

	public boolean changeBattery() {
		// TODO Auto-generated method stub
		return false;
	}

	public int getBatteryPercentage() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getStrapColor() {
		// TODO Auto-generated method stub
		return null;
	}

	public void sendSMS() {
		// TODO Auto-generated method stub
		
	}

	public boolean connectToPhone() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean turnBlueTooth() {
		// TODO Auto-generated method stub
		return false;
	}

	public int getStepCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getHeartBeat() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setGoal(int steps) {
		// TODO Auto-generated method stub
		
	}

	public abstract int getBPM();

	
}
