package week3.day2;

public class AppleWatch implements SmartWatch{
	
	public AppleWatch() {
		// TODO Auto-generated constructor stub
	}

	public String getDateTime() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setDateTime(String newDate) {
		// TODO Auto-generated method stub
		
	}

	public boolean changeBattery() {
		// TODO Auto-generated method stub
		return false;
	}

	public int getBatteryPercentage() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getStrapColor() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean connectToPhone() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean turnBlueTooth() {
		// TODO Auto-generated method stub
		return false;
	}

	public int getStepCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getHeartBeat() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setGoal(int steps) {
		// TODO Auto-generated method stub
		
	}

}
