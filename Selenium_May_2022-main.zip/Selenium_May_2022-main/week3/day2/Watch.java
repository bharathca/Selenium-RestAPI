package week3.day2;




public interface Watch {
	
	
	public String getDateTime();
	
	public void setDateTime(String newDate);
	
	public boolean changeBattery();
	
	public int getBatteryPercentage();
	
	public String getStrapColor();
	
	
	

}
