package week6.day1;

import org.testng.annotations.Test;

public class LearnAnnotations2 extends BaseClass{

	@Test
	public void test1() {
		System.out.println("Test1");
	}
	
	@Test
	public void test2() {
		System.out.println("Test2");
	}
}
