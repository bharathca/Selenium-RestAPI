package week1.day1;

public class LearnLoopingStatement {

	public static void main(String[] args) {
		// Print from 1 to 5
//		for(intialisation; condition; increment/ decrement)
		for(int i=1; i<=5; i++) {
			System.out.println(i);
		}
		
		for(int i=5; i> 0;i--)
			System.out.println(i);
		
		for(int i=1; i<=5; i++) {
			System.out.println("Welcome to TestLeaf");
		}
		
	}

}
