package week1.day1;

public class Mobiles {
	
	public void makeCall() {
		System.out.println("Make Call");
	}
	
	public void sendMsg() {
		System.out.println("Send Msg");
	}

	public static void main(String[] args) {
		Mobiles mobiles = new Mobiles();
		mobiles.makeCall();
//		mobiles.sendMsg();
		
	}

}
