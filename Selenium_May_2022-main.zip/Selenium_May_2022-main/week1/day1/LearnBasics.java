package week1.day1;

public class LearnBasics {

	public static void main(String[] args) {
		System.out.println("In Learn Basics class");
	}

}
