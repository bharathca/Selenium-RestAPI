package week1.day2;

public class LearnWhileLoop {

	public static void main(String[] args) {
		// print 1 to 5
		int num = 1;
		while(num <= 5) {
			System.out.println(num);
			num++;
			// num = num+1;
		}
	}

}
