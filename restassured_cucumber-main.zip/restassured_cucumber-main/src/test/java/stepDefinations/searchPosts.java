package stepDefinations;


import static io.restassured.RestAssured.given;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import jdk.internal.net.http.common.Log;
import stepDefinations.BaseClass;

public class searchPosts {

	public BaseClass Base;
	
	//dependency injection
	public searchPosts(BaseClass Base) {
		this.Base = Base;
	}

	
	@Given("I want to search posts with {string} {string}")
	public void i_want_to_search_posts_with(String Parameter, String Value) {
		Base.request = given().params(Parameter, Value);
	
	}
	
	
	@When("I fetch the post by making a call to the service")
	public void i_fetch_the_post_by_making_a_call_to_the_service() {
		Base.response = Base.request.when().get(Base.baseURI + "posts");
		System.out.println("response: " + Base.response.prettyPrint());

	}



}
