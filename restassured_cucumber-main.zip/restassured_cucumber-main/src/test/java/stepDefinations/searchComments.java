package stepDefinations;

import static io.restassured.RestAssured.given;

import static org.hamcrest.Matchers.hasItem;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class searchComments {

public BaseClass Base;
	

	public searchComments(BaseClass Base) {
		this.Base = Base;
	}
	
	@Given("a user exists with {string} {string}")
	public void a_user_exists_with(String parameter, String value) {
		Base.request = given().params(parameter, value);
	}
	

	@When("I fetch the comment by making call to the service")
	public void i_fetch_the_comment_by_making_call_to_the_service() {
		Base.response = Base.request.when().get(Base.baseURI + "comments");
		System.out.println("response: " + Base.response.prettyPrint());
	}
	

	@Then("Validate the email address is correct")
	public void validate_the_email_address_is_correct() {
	      // Storing all the emails from the response in the list
		  JsonPath jsonPathEvaluator = Base.response.jsonPath();
	      List<String> emailsList =jsonPathEvaluator.getList("email");
	      System.out.println("email list : "+ emailsList);
	      
	      //Validating each email from the list with the give pattern
	      String regex = "^(.+)@(.+)$";
	      
		  Pattern pattern = Pattern.compile(regex);
	      for (Object email : emailsList) {
	          Matcher matcher = pattern.matcher((CharSequence) email);
	          System.out.println(email + " :" + matcher.matches());
	       } 
		
	}






}
