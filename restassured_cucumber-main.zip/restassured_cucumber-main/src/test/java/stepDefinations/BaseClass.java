package stepDefinations;

import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class BaseClass {
	String baseURI = "https://jsonplaceholder.typicode.com/"; //end point
	
	// common data to be used across all step definition classes
	protected Response response;
	protected RequestSpecification request;	
	
	
}
