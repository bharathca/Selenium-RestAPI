package stepDefinations;


import static io.restassured.RestAssured.given;

import org.hamcrest.Matchers;
import org.junit.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import stepDefinations.BaseClass;

public class searchUser {
	public BaseClass Base;
	

	public searchUser(BaseClass Base) {
		this.Base = Base;
	}
	
	@Given("I want to search a user with {string} {string}")
	public void i_want_to_search_a_user_with(String parameter, String value) {
		Base.request = given().params(parameter, value);
	}
	
	
	@When("I searches for the user by making a call to the service")
	public void i_searches_for_the_user_by_making_a_call_to_the_service() {
		Base.response = Base.request.get(Base.baseURI+"users");
		System.out.println("response: " + Base.response.prettyPrint());
	
	}
	
	
	@Then("valid response with status code {long} should be returned")
	public void valid_response_with_status_code_should_be_returned(long statusCode) {
		 Assert.assertEquals(statusCode, Base.response.getStatusCode());

	}

	@Then("an empty response should be returned")
	public void an_empty_response_should_be_returned() {
		Base.response.then().body("isEmpty()", Matchers.is(true));
	}








}
