# Mobiquity QA Assignment

This is a basic Rest API test framework for testing the search user , search post and search comment sceanrio for https://jsonplaceholder.typicode.com/. Tests are written using a combination of
Rest Assured, Cucumber, Junit & Maven.

## Tools

* Java
* Cucumber6:
  * Supports Behaviour Driven Development
  * Web Based Test Reports which can be uploaded on GitHub (see Test Reports section below)
* Hamcrest framework for customized assertion matchers
* RESTAssured library for writing simple yet powerful tests

## Test Cases Covered

The following tests were covered:

* Search user
1. Search for user with username.
2. Search for user with id.
3. Search for user with name.
4. Search for user with email.
5. Search for user with phone.
6. Search for user with website.
7. Search for user with company name.
8. Negative validation for search user with non existing username
9. Negative validation for search user with non existing id.

* Search Posts
10. Search for post with userId
11. Search for post with title
12. Search for post with id
13. Negative validation Search for post with non existing userId
14. Negative validation Search for post with non existing title
15. Negative validation Search for post with non existing id

* Search comment and validate email
16. Search comments for posts by postId and validate email address
17. Search comments for posts by Id and validate email address


## How to execute

Requirements to run test:
1. JDK 14.0.1 
2. Maven 3.8.5
3. To run through
(i) Terminal: execute command `mvn clean test` (after navigating to project on terminal).
(ii) Eclipse IDE: run MyTestRunner.java as a JUnit test.

## Test Reports

Following the execution of a test, an HTML Cucumber report is generated under  target/Extent-reports/Test-output <date and time stamp>/Reports.html
