package models;
import lombok.Data;

@Data
public class Geo {
    private Double lat;
    private Double lng;
}
