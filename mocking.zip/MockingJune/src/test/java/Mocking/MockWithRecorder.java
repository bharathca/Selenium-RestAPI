package Mocking;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class MockWithRecorder {
	
	@Test
	public void recorder() {
		
		RestAssured.baseURI="http://localhost:8080/api/now/table/incident";
		RestAssured.authentication = RestAssured.basic("admin", "/VdUgPUe*46w");
		
		Response response = RestAssured.given().contentType(ContentType.JSON).post();
		
		response.prettyPrint();
		System.out.println(response.statusCode());
		
	}

}
