package Mocking;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.github.tomakehurst.wiremock.client.WireMock;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class MockwithStub {
	
	@BeforeMethod
	public void stubBuild() {
		WireMock.stubFor(WireMock.post("/api/now/table/incident")
				.willReturn(WireMock.aResponse().withStatus(201).withHeader("content-type", "application/json")
						.withBody("{\r\n"
								+ "    \"category\":\"software\",\r\n"
								+ "    \"short_description\":\"Post request with string as body\"\r\n"
								+ "}")));
		
	}
	
	
	
	@Test
	public void stubTest() {
		
		RestAssured.baseURI = "http://localhost/api/now/table/incident";
		Response response = RestAssured.given()
				   .contentType(ContentType.JSON)
				   .post();
		
		response.prettyPrint();
		System.out.println(response.statusCode());
		System.out.println(response.statusLine());
	}

}
