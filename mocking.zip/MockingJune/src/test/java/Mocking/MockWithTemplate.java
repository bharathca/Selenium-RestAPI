package Mocking;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class MockWithTemplate {

	
	@Test
	public void mockTemplate() {
		RestAssured.baseURI = "http://localhost:8080/testleaf/training/course";
		RestAssured.authentication = RestAssured.oauth2("");
		
		Response response = RestAssured.given()
				   .queryParam("course_name", "REST-ASSURED")
				   .queryParam("Mode_Of_Learning", "ONLINE")
				   .contentType(ContentType.JSON)
				   .get();
		
		response.prettyPrint();
		System.out.println(response.statusCode());
	}
}
