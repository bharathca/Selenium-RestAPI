package week3.day2.assignments;

import java.util.List;
import java.util.Random;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class JiraAssignments extends BaseClass{
	
	/*
	 * 
	 * ---------------------Assignment 3 - RESTAssured--------------------------------------
		a. Get all the issues from Jira that were created less than 5 hours and print the count of the issues
		b. add status code and response time assertions
		c. Verify the field "key" contains the String "June" using assertion
		d. Verify the length of the field "key" is 7
	 * 
	 * 
	 * 
	 * 
	 */
	
	@Test
	public void getAllIssues5Hours() {
		response = request
						.given()
							.queryParam("jql", "project=May and created>-5h")
							.get("search");				
		response.then().assertThat()
							.statusCode(200)
							.time(Matchers.lessThan(7000L))
							.body("issues[0].key", Matchers.containsString("MAY"))
							.body("issues[0].key.size()", Matchers.is(8)); 
	}	
	
	
	/*
	 * 
	 * --------------------Assignment 5 - RESTAssured--------------------------------------
a. Randomly get a issue from Jira and update that issue
b. add status code and status line assertions
c. add a assertion to verify the response field is empty
-------------------------------------------------------------------------------------
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	
	@Test
	private void randomUpdate() {		
		response = request.get("search");
		List<String> list = response.jsonPath().getList("issues.key");
		Random rand = new Random();
	    String randomElement = list.get(rand.nextInt(list.size()));
	    System.out.println("Key Value => "+randomElement);
		
		response = request.given()
							.body("{\r\n"
									+ "    \"fields\": {\r\n"
									+ "        \"project\": { \"key\": \"MAY\" },\r\n"
									+ "        \"description\": \"Updated via Rest-Assureda\",\r\n"
									+ "        \"issuetype\": { \"name\": \"Task\" }\r\n"
									+ "    }\r\n"
									+ "}")
							.put("issue/"+randomElement);
		response.then().assertThat()
							.statusCode(204).and()
							.statusLine("HTTP/1.1 204 No Content")
							.and()
							.body(Matchers.blankOrNullString())
							.and()
							.contentType(ContentType.JSON);

	}

}
